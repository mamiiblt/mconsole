﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mConsole_Windows_Interactive
{
    public partial class selectTaskType : Form
    {
        public selectTaskType()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            main.taskrunning = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            runTaskNumber rtn = new runTaskNumber();
            rtn.Show();
        }
    }
}
