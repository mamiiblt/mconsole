﻿namespace mConsole_Windows_Interactive
{
    partial class main
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.görevÇalıştırtextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.görevÇalıştırtextToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.görevSonlandırtextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.yardımToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dilDeğiştirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.debugModuGeliştiriciklerİçinToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.debuguAçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.diğerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programHakkındaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programıKapatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.görevÇalıştırtextToolStripMenuItem,
            this.dilToolStripMenuItem,
            this.debugModuGeliştiriciklerİçinToolStripMenuItem,
            this.diğerToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(336, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // görevÇalıştırtextToolStripMenuItem
            // 
            this.görevÇalıştırtextToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.görevÇalıştırtextToolStripMenuItem1,
            this.görevSonlandırtextToolStripMenuItem,
            this.yardımToolStripMenuItem});
            this.görevÇalıştırtextToolStripMenuItem.Name = "görevÇalıştırtextToolStripMenuItem";
            this.görevÇalıştırtextToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.görevÇalıştırtextToolStripMenuItem.Text = "Görev ";
            this.görevÇalıştırtextToolStripMenuItem.Click += new System.EventHandler(this.görevÇalıştırtextToolStripMenuItem_Click);
            // 
            // görevÇalıştırtextToolStripMenuItem1
            // 
            this.görevÇalıştırtextToolStripMenuItem1.Name = "görevÇalıştırtextToolStripMenuItem1";
            this.görevÇalıştırtextToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.görevÇalıştırtextToolStripMenuItem1.Text = "Görev Çalıştır";
            this.görevÇalıştırtextToolStripMenuItem1.Click += new System.EventHandler(this.görevÇalıştırtextToolStripMenuItem1_Click);
            // 
            // görevSonlandırtextToolStripMenuItem
            // 
            this.görevSonlandırtextToolStripMenuItem.Name = "görevSonlandırtextToolStripMenuItem";
            this.görevSonlandırtextToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.görevSonlandırtextToolStripMenuItem.Text = "Görev Sonlandır";
            this.görevSonlandırtextToolStripMenuItem.Click += new System.EventHandler(this.görevSonlandırtextToolStripMenuItem_Click);
            // 
            // yardımToolStripMenuItem
            // 
            this.yardımToolStripMenuItem.Name = "yardımToolStripMenuItem";
            this.yardımToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.yardımToolStripMenuItem.Text = "Yardım";
            this.yardımToolStripMenuItem.Click += new System.EventHandler(this.yardımToolStripMenuItem_Click);
            // 
            // dilToolStripMenuItem
            // 
            this.dilToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dilDeğiştirToolStripMenuItem});
            this.dilToolStripMenuItem.Name = "dilToolStripMenuItem";
            this.dilToolStripMenuItem.Size = new System.Drawing.Size(33, 20);
            this.dilToolStripMenuItem.Text = "Dil";
            // 
            // dilDeğiştirToolStripMenuItem
            // 
            this.dilDeğiştirToolStripMenuItem.Name = "dilDeğiştirToolStripMenuItem";
            this.dilDeğiştirToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.dilDeğiştirToolStripMenuItem.Text = "Dil Değiştir";
            this.dilDeğiştirToolStripMenuItem.Click += new System.EventHandler(this.dilDeğiştirToolStripMenuItem_Click);
            // 
            // debugModuGeliştiriciklerİçinToolStripMenuItem
            // 
            this.debugModuGeliştiriciklerİçinToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.debuguAçToolStripMenuItem});
            this.debugModuGeliştiriciklerİçinToolStripMenuItem.Name = "debugModuGeliştiriciklerİçinToolStripMenuItem";
            this.debugModuGeliştiriciklerİçinToolStripMenuItem.Size = new System.Drawing.Size(189, 20);
            this.debugModuGeliştiriciklerİçinToolStripMenuItem.Text = "Debug Modu (Geliştiricikler İçin)";
            // 
            // debuguAçToolStripMenuItem
            // 
            this.debuguAçToolStripMenuItem.Name = "debuguAçToolStripMenuItem";
            this.debuguAçToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.debuguAçToolStripMenuItem.Text = "Debug\'u Aç";
            this.debuguAçToolStripMenuItem.Click += new System.EventHandler(this.debuguAçToolStripMenuItem_Click);
            // 
            // diğerToolStripMenuItem
            // 
            this.diğerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.programHakkındaToolStripMenuItem,
            this.programıKapatToolStripMenuItem});
            this.diğerToolStripMenuItem.Name = "diğerToolStripMenuItem";
            this.diğerToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.diğerToolStripMenuItem.Text = "Diğer";
            // 
            // programHakkındaToolStripMenuItem
            // 
            this.programHakkındaToolStripMenuItem.Name = "programHakkındaToolStripMenuItem";
            this.programHakkındaToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.programHakkındaToolStripMenuItem.Text = "Program Hakkında";
            this.programHakkındaToolStripMenuItem.Click += new System.EventHandler(this.programHakkındaToolStripMenuItem_Click);
            // 
            // programıKapatToolStripMenuItem
            // 
            this.programıKapatToolStripMenuItem.Name = "programıKapatToolStripMenuItem";
            this.programıKapatToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.programıKapatToolStripMenuItem.Text = "Programı Kapat";
            this.programıKapatToolStripMenuItem.Click += new System.EventHandler(this.programıKapatToolStripMenuItem_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 26);
            this.ControlBox = false;
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "main";
            this.Text = "mConsole UI";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem görevÇalıştırtextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem görevÇalıştırtextToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem görevSonlandırtextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem yardımToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dilDeğiştirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem debugModuGeliştiriciklerİçinToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem debuguAçToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem diğerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programıKapatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programHakkındaToolStripMenuItem;
    }
}

