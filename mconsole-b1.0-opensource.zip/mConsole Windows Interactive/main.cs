﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mConsole_Windows_Interactive
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            switch (e.CloseReason)
            {
                case CloseReason.UserClosing:
                    e.Cancel = true;
                    break;
            }
            base.OnFormClosing(e);
        }

        private void görevÇalıştırtextToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public static bool taskrunning; 

        private void görevÇalıştırtextToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (taskrunning == false)
            {
                selectTaskType stt = new selectTaskType();
                stt.Show();
                taskrunning = true;
            }

        }

        private void görevSonlandırtextToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void yardımToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void programıKapatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (taskrunning == true)
            {
                uyari uyr = new uyari();
                uyr.Show();
            }
            else
            {
                Application.Exit();
            }
        }

        private void programHakkındaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            aboutApp aba = new aboutApp();
            aba.Show();
        }

        private void debuguAçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debugMode dbg = new debugMode();
            dbg.Show();
        }

        private void dilDeğiştirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debugMode dbg = new debugMode();
            dbg.Show();
        }
    }
}
