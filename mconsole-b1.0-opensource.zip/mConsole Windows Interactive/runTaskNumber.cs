﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mConsole_Windows_Interactive
{
    public partial class runTaskNumber : Form
    {
        public runTaskNumber()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            selectTaskType rtn = new selectTaskType();
            rtn.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string id = Convert.ToString(enterid.Text);

            if (id == "a01")
            {
                this.Close();
                a01 a01 = new a01();
                a01.Show();
            }
            if (id != "a01")
            {
                this.Close();
                pleaseEnterCorrectCode pecc = new pleaseEnterCorrectCode();
                pecc.Show();
            }
        }

        private void enterid_TextChanged(object sender, EventArgs e)
        {

        }

        private void enterid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string id = Convert.ToString(enterid.Text);

                if (id == "a01")
                {
                    this.Close();
                    a01 a01 = new a01();
                    a01.Show();
                }
                if (id != "a01")
                {
                    this.Close();
                    pleaseEnterCorrectCode pecc = new pleaseEnterCorrectCode();
                    pecc.Show();
                }
            }
        }
    }
}
